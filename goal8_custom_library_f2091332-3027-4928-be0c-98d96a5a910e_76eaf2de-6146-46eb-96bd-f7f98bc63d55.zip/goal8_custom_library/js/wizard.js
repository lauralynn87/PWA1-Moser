// Wizard Class File
// Keep the constructor small- Use the prototype






